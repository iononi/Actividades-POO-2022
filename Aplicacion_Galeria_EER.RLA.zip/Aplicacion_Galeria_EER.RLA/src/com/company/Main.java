package com.company;
import com.company.window.CustomWindow;
//SegundoParcial Aplicacion Galeria// Eduardo Ruiz Rios & Roberto Lagunes Alvarez

public class Main {

    public static void main(String[] args) {
	    new CustomWindow().setVisible(true); //Hacemos visible la ventana
    }
}
